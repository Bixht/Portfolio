const navbarMenu = document.getElementById("navbar");
const burgerMenu = document.getElementById("burger");
const overlayMenu = document.querySelector(".overlay");

const toggleMenu = () => {
    navbarMenu.classList.toggle("active");
    overlayMenu.classList.toggle("active");
};

const collapseSubMenu = () => {
    navbarMenu
        .querySelector(".menu-dropdown.active .submenu")
        .removeAttribute("style");
    navbarMenu.querySelector(".menu-dropdown.active").classList.remove("active");
};

const toggleSubMenu = (e) => {
    if (e.target.hasAttribute("data-toggle") && window.innerWidth <= 992) {
        e.preventDefault();
        const menuDropdown = e.target.parentElement;

        if (menuDropdown.classList.contains("active")) {
            collapseSubMenu();
        } else {
            if (navbarMenu.querySelector(".menu-dropdown.active")) {
                collapseSubMenu();
            }
            menuDropdown.classList.add("active");
            const subMenu = menuDropdown.querySelector(".submenu");
            subMenu.style.maxHeight = subMenu.scrollHeight + "px";
        }
    }
};

const resizeWindow = () => {
    if (window.innerWidth > 992) {
        if (navbarMenu.classList.contains("active")) {
            toggleMenu();
        }
        if (navbarMenu.querySelector(".menu-dropdown.active")) {
            collapseSubMenu();
        }
    }
};

burgerMenu.addEventListener("click", toggleMenu);
overlayMenu.addEventListener("click", toggleMenu);
navbarMenu.addEventListener("click", toggleSubMenu);
window.addEventListener("resize", resizeWindow);






// searchModal 

const modal = document.getElementById('searchModal');
const searchToggle = document.getElementById('searchToggle');
const closeModal = document.getElementById('closeModal');

searchToggle.addEventListener('click', function(event) {
    event.preventDefault(); 
    modal.style.display = 'block';
});


closeModal.addEventListener('click', function() {
    modal.style.display = 'none';
});


window.addEventListener('click', function(event) {
    if (event.target === modal) {
        modal.style.display = 'none';
    }
});







// hero-carousel
$('#hero-carousel').owlCarousel({
    loop: true,
    margin: 10,
    dots: true,
    nav: false,
    mouseDrag: false,
    autoplay: false,
    autoplayTimeout: 5000,
    smartSpeed: 1000,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 1
        }
    }
});



// slider-carousel
$(document).ready(function () {
    $("#slider-carousel").owlCarousel({
        items: 5,
        loop: true,
        margin: 10,
        nav: true,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        navText: ['<span class="fa fa-angle-left   slick-prev-in" aria-hidden="true""></span>', '<span class="fa fa-angle-right slick-next-in " aria-hidden="true"></span>',],
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 3
            },
            1200: {
                items: 5
            }
        }
    });
});



//   card-carousel
$(document).ready(function () {
    $("#card-carousel").owlCarousel({
        items: 4,
        loop: true,
        margin: 10,
        nav: true,
        dots: true,
        autoplay: true,
        autoplayTimeout: 3000,
        navText: ['<span class="fa fa-angle-left   slick-prev-in card-prev" aria-hidden="true""></span>', '<span class="fa fa-angle-right slick-next-in   card-next" aria-hidden="true"></span>',],
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 3
            },
            1200: {
                items: 4
            }
        }
    });
});





//   card-new_slider
$(document).ready(function () {
    $("#card-new_slider").owlCarousel({
        items: 3,
        loop: true,
        margin: 10,
        nav: false,
        dots: true,
        autoplay: true,
        autoplayTimeout: 3000,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 2
            },
            1200: {
                items: 3
            }
        }

    });
});


$(document).ready(function () {
    $("#printe-parts-slider").owlCarousel({
        items: 3,
        loop: true,
        margin: 10,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 2
            },
            1200: {
                items: 3
            }
        }

    });
});
//   card-best_slider
$(document).ready(function () {
    $("#card-best_slider").owlCarousel({
        items: 3,
        loop: true,
        margin: 10,
        nav: false,
        dots: true,
        autoplay: true,
        autoplayTimeout: 3000,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 2
            },
            1200: {
                items: 3
            }
        }
    });
});


//   card-best_slider
$(document).ready(function () {
    $("#printe-parts-card-best").owlCarousel({
        items: 3,
        loop: true,
        margin: 10,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 2
            },
            1200: {
                items: 3
            }
        }
    });
});


// clients-carousel
$('.clients-carousel').owlCarousel({
    loop: true,
    nav: false,
    dots: true,
    autoplay: true,
    autoplayTimeout: 5000,
    smartSpeed: 450,
    margin: 30,
    responsive: {
        0: {
            items: 1
        },
        768: {
            items: 1
        },
        991: {
            items: 1
        },
        1200: {
            items: 1
        },
        1920: {
            items: 1
        }
    }
});


// center-slider 
$(document).ready(function () {
    $('.center-slider').owlCarousel({
        loop: true,
        autoplay: true,
        dots: false,
        center: true,
        responsiveClass: true,
        responsive: {
            0: {
                items: 1,
                autoplayTimeout: 3000,
                smartSpeed: 500
            },
            600: {
                items: 1,
                autoplayTimeout: 4000,
                smartSpeed: 800
            },
            1000: {
                items: 2,
                autoplayTimeout: 5000,
                smartSpeed: 1000
            },
            1200: {
                items: 3,
                autoplayTimeout: 6000,
                smartSpeed: 1200
            }
        }
    });
});



// products-new_slider
$(document).ready(function () {
    $("#products-new_slider").owlCarousel({
        items: 3,
        loop: true,
        margin: 10,
        nav: false,
        dots: true,
        autoplay: true,
        autoplayTimeout: 3000,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 3
            },
            1200: {
                items: 5
            }
        }

    });
});

// Product-detail  

$(document).ready(function () {

    var sync1 = $("#sync1");
    var sync2 = $("#sync2");
    var slidesPerPage = 4; 
    var syncedSecondary = true;

    sync1.owlCarousel({
        items: 1,
        slideSpeed: 2000,
        autoplayHoverPause: true,
        nav: false,
        dots: false,
        loop: true,
        rtl: true,
        responsiveRefreshRate: 200,
    }).on('changed.owl.carousel', syncPosition);

    sync2
        .on('initialized.owl.carousel', function () {
            sync2.find(".owl-item").eq(0).addClass("current");
        })
        .owlCarousel({
            items: slidesPerPage,
            dots: false,
            nav: false,
            smartSpeed: 200,
            slideSpeed: 500,
            slideBy: slidesPerPage,
            rtl: true,
            responsiveRefreshRate: 100,
            responsive: {
                0:{
                    items: 2
                },
                576: {
                    items: 3
                },
                600: {
                    items: 3
                },
                1000: {
                    items: 4
                }
            }
        }).on('changed.owl.carousel', syncPosition2);

    function syncPosition(el) {
        var count = el.item.count - 1;
        var current = Math.round(el.item.index - (el.item.count / 2) - .5);

        if (current < 0) {
            current = count;
        }
        if (current > count) {
            current = 0;
        }


        sync2
            .find(".owl-item")
            .removeClass("current")
            .eq(current)
            .addClass("current");
        var onscreen = sync2.find('.owl-item.active').length - 1;
        var start = sync2.find('.owl-item.active').first().index();
        var end = sync2.find('.owl-item.active').last().index();

        if (current > end) {
            sync2.data('owl.carousel').to(current, 100, true);
        }
        if (current < start) {
            sync2.data('owl.carousel').to(current - onscreen, 100, true);
        }
    }

    function syncPosition2(el) {
        if (syncedSecondary) {
            var number = el.item.index;
            sync1.data('owl.carousel').to(number, 100, true);
        }
    }

    sync2.on("click", ".owl-item", function (e) {
        e.preventDefault();
        var number = $(this).index();
        sync1.data('owl.carousel').to(number, 300, true);
    });
});


// Brand js 

document.querySelector('.brandTitle').addEventListener('click', function () {
    const brandBox = document.querySelector('.Brand-box.brandBox');
    if (brandBox.style.display === 'none' || brandBox.style.display === '') {
        brandBox.style.display = 'block';
    } else {
        brandBox.style.display = 'none';
    }
});






// quantity_value js

const decreaseButton = document.getElementById('decrease');
const increaseButton = document.getElementById('increase');
const quantityInput = document.getElementById('number');

decreaseButton.addEventListener('click', () => {
    let currentValue = parseInt(quantityInput.value);
    if (currentValue > 1) {
        quantityInput.value = currentValue - 1;
    }
});

increaseButton.addEventListener('click', () => {
    let currentValue = parseInt(quantityInput.value);
    quantityInput.value = currentValue + 1;
});


